<div class="review">
    <h4>{{ $review->user->name }}</h4>
    <p>⭐ {{ $review->rating }} / 5</p>
    <p>{{ $review->comment }}</p>
    <hr>
</div>